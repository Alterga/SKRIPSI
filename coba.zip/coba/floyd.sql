-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Mar 2021 pada 09.25
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `floyd`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `desa`
--

CREATE TABLE `desa` (
  `id` int(3) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kode` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jalanan`
--

CREATE TABLE `jalanan` (
  `id` int(4) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kecamatan`
--

CREATE TABLE `kecamatan` (
  `id` int(3) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `kodewl` varchar(10) NOT NULL,
  `info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kecamatan`
--

INSERT INTO `kecamatan` (`id`, `nama`, `kode`, `kodewl`, `info`) VALUES
(1, 'Bulu', '59255', '33.17.02 ', 'a'),
(2, 'Gunem ', '59263', '33.17.03 ', 'a'),
(3, 'Kaliori ', '59252', '33.17.09 ', 'a'),
(4, 'Kragan ', '59273', '33.17.12 ', 'a'),
(5, 'Lasem ', '59271', '33.17.14 ', 'a'),
(6, 'Pamotan ', '59261', '33.17.07 ', 'a'),
(7, 'Pancur ', '59262 ', '33.17.11 ', 'a'),
(8, 'Rembang ', '59211 ', '33.17.10 ', 'a'),
(9, 'Sale ', '59265 ', '33.17.04 ', 'a'),
(10, 'Sarang ', '59274 ', '33.17.05 ', 'a'),
(11, 'Sedan ', '59264 ', '33.17.06 ', 'a'),
(12, 'Sluke ', '59272 ', '33.17.13 ', 'a'),
(13, 'Sulang ', '59254 ', '33.17.08 ', 'a'),
(14, 'Sumber ', '59253 ', '33.17.01 ', 'a');

-- --------------------------------------------------------

--
-- Struktur dari tabel `lokasi`
--

CREATE TABLE `lokasi` (
  `id` int(11) NOT NULL,
  `nama_lokasi` varchar(100) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `lokasi` varchar(100) NOT NULL,
  `harga` int(10) NOT NULL,
  `fasilitas` text NOT NULL,
  `jam` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `lokasi`
--

INSERT INTO `lokasi` (`id`, `nama_lokasi`, `latitude`, `longitude`, `lokasi`, `harga`, `fasilitas`, `jam`) VALUES
(1, 'Jakarta', '-6.208760', '106.845599', '', 0, '', ''),
(2, 'Makassar', '-5.147696', '119.432593', '', 0, '', ''),
(3, 'Padang', '-0.947110', '100.414603', '', 0, '', ''),
(4, 'Pontianak', '-0.027842', '109.344250', '', 0, '', ''),
(5, 'Manokwari', '-0.861277', '134.062422', '', 0, '', ''),
(6, 'Nabire', '-3.371565', '135.501464', '', 0, '', ''),
(7, 'Yogyakarta', '-7.795766', '110.369866', '', 0, '', ''),
(8, 'Bali', '-8.344295', '115.101547', '', 0, '', ''),
(9, 'Palangkaraya', '-2.216392', '113.921577', '', 0, '', ''),
(10, 'Palembang', '-2.976224', '104.773948', '', 0, '', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `desa`
--
ALTER TABLE `desa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jalanan`
--
ALTER TABLE `jalanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kecamatan`
--
ALTER TABLE `kecamatan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
